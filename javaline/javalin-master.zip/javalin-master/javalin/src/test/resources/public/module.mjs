export function test() {
    return 'mjs works'
}
