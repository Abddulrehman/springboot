<template id="view-one-3">
    <dependency-one-3></dependency-one-3>
</template>
<script>
    app.component("view-one-3",{template:"#view-one-3"})
</script>

