<template id="dependency-three">
    <div>Dependency Three</div>
</template>
<template id="dependency-four">
    <div>Dependency Four</div>
</template>
<script>
    Vue.component('dependency-three',{template:"#dependency-three"});
    Vue.component('dependency-four',{template:"#dependency-four"});
</script>

