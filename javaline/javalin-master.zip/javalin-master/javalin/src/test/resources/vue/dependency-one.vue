<template id="dependency-one">
    <div>Dependency One</div>
</template>
<script>
    Vue.component('dependency-one',{template:"#dependency-one"});
</script>
