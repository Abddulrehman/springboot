<template id="dependency-1">
    <div>Dependency 1</div>
</template>
<script>
    Vue.component('dependency-1',{template:"#dependency-1"});
</script>
