<template id="test-component-3">
    <div>Test ÆØÅ</div>
</template>
<script>
    app.component("test-component-3", {template: "#test-component-3"});
</script>

