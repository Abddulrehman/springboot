<template id="view-number-dependency">
    <dependency-1></dependency-1>
    <dependency-1-foo></dependency-1-foo>
</template>
<script>
    Vue.component("view-number-dependency",{template:"#view-number-dependency"})
</script>
