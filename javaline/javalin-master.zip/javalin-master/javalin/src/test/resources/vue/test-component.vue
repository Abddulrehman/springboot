<template id="test-component">
    <div>Test ÆØÅ</div>
</template>
<script>
    Vue.component("test-component", {template: "#test-component"});
</script>

