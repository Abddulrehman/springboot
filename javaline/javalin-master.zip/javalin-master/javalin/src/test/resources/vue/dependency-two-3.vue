<template id="dependency-two-3">
    <div>Dependency Two</div>
</template>
<script>
    app.component('dependency-two-3',{template:"#dependency-two-3"});
</script>

