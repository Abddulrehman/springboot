<template id="nested-dependency">
    <dependency-one></dependency-one>
    <dependency-two></dependency-two>
</template>
<script>
    Vue.component('nested-dependency',{template:"#nested-dependency"})
</script>

