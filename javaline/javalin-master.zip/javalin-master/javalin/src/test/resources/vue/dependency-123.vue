<template id="dependency-123">
    <div>Dependency 123</div>
</template>
<script>
    Vue.component('dependency-123',{template:"#dependency-123"});
</script>
