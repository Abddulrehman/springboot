<template id="view-one">
    <dependency-one></dependency-one>
</template>
<script>
    Vue.component("view-one",{template:"#view-one"})
</script>

