<template id="view-nested-dependency">
    <nested-dependency></nested-dependency>
</template>
<script>
    Vue.component("view-nested-dependency",{template:"#view-nested-dependency"});
</script>
