<template id="view-two">
    <dependency-three></dependency-three>
</template>
<script>
    Vue.component("view-two",{template:"#view-two"})
</script>

