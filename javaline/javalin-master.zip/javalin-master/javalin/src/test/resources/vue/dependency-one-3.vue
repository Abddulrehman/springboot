<template id="dependency-one-3">
    <div>Dependency One</div>
</template>
<script>
    app.component('dependency-one-3',{template:"#dependency-one-3"});
</script>
