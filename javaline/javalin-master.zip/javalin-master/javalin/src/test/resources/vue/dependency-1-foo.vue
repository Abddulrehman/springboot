<template id="dependency-1-foo">
    <div>Dependency 1 foo</div>
</template>
<script>
    Vue.component('dependency-1-foo',{template:"#dependency-1-foo"});
</script>
