<template id="view-three">
    <dependency-four></dependency-four>
</template>
<script>
    Vue.component("view-three",{template:"#view-three"})
</script>

