<template id="dependency-two">
    <div>Dependency Two</div>
</template>
<script>
    Vue.component('dependency-two',{template:"#dependency-two"});
</script>

