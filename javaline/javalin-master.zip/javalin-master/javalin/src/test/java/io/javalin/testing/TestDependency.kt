package io.javalin.testing

object TestDependency {
    val swaggerVersion = "4.10.3";
}
