package io.javalin.testing;

import java.io.Serializable;

public class SerializableObject implements Serializable {
    public String value1 = "FirstValue";
    public String value2 = "SecondValue";
}
