package io.javalin.testing;

public class NonSerializableObject {
    private final String value1 = "First value";
    private final String value2 = "Second value";
}
